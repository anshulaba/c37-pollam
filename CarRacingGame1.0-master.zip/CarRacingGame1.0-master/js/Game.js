class Game {
  constructor()
  {

  }

  getState(){
    var gameStateRef  = database.ref('gameState');
    gameStateRef.on("value",function(data){
       gameState = data.val();
    })

  }

  update(state){
    database.ref('/').update({
      gameState: state
    });
  }

  async start(){

    
  }

  play()
  {
    form.hide();
    textSize(40);
    text("gameStart",120,100);
    player.getPlayerInfo();
    if(allPlayers!==undefined)
    {
    var display_position=130;
     display_position=display_position+20;
     textSize(15);
     text(allPlayers[plr].name + ":" + allplayers[plr].distance,120,display_position);


    }

  }
}
